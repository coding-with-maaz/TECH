<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
<?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e($url['loc']); ?></loc>
        <?php if(isset($url['lastmod'])): ?>
        <lastmod><?php echo e($url['lastmod']); ?></lastmod>
        <?php endif; ?>
        <?php if(isset($url['image'])): ?>
        <image:image>
            <image:loc><?php echo e($url['image']['loc']); ?></image:loc>
            <?php if(!empty($url['image']['title'])): ?>
            <image:title><![CDATA[<?php echo e($url['image']['title']); ?>]]></image:title>
            <?php endif; ?>
            <?php if(!empty($url['image']['caption'])): ?>
            <image:caption><![CDATA[<?php echo e($url['image']['caption']); ?>]]></image:caption>
            <?php endif; ?>
        </image:image>
        <?php endif; ?>
    </url>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>


<?php /**PATH C:\Users\k\Desktop\Nazaarabox - Copy\resources\views/sitemap/images.blade.php ENDPATH**/ ?>