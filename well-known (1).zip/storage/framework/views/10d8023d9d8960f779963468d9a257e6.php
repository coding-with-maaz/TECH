<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
              xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
              xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd">
<!-- created with Free Online Sitemap Generator www.xml-sitemaps.com -->
<?php $__currentLoopData = $sitemaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sitemap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <sitemap>
        <loc><?php echo e($sitemap['loc']); ?></loc>
        <?php if(isset($sitemap['lastmod'])): ?>
        <lastmod><?php echo e($sitemap['lastmod']); ?></lastmod>
        <?php endif; ?>
    </sitemap>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</sitemapindex>

<?php /**PATH C:\Users\k\Desktop\Nazaarabox - Copy\resources\views/sitemap/index-file.blade.php ENDPATH**/ ?>