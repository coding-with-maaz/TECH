<?php
header("Content-Type: text/plain");
echo "google.com, pub-2809929499941883, DIRECT, f08c47fec0942fa0";
